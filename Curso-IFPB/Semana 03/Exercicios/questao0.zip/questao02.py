inicio = 1 
fina = 50
passo = 2
for n in range (inicio,fina,passo):
    print(n)
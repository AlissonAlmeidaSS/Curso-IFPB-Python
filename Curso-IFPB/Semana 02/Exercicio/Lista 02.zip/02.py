letra=input("Digite uma Letra ")
if (((letra == "a")or(letra == "A"))or((letra == "e")or(letra == "E"))or((letra == "o")or(letra == "O"))or((letra == "u")or(letra == "U"))):
    print("Vogal")
else:
    print("Consoante")
teste = 10
value= int(input("Digite um Numero: "))
if (value< teste):
    print ("Valor menor que",teste)
if (value > teste):
    print ("Valor maior que",teste)
if (value == teste):
    print ("Voce acertou")

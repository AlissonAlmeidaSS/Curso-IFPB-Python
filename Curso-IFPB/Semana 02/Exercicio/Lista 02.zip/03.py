produto1=input("Digite o nome do primeiro Produto: ")
valor01 = float(input("Digite o Valor do primeiro Produto: "))
produto2=input("Digite o nome do primeiro Produto: ")
valor02= float(input("Digite o Valor do primeiro Produto: "))
produto3=input("Digite o nome do primeiro Produto: ")
valor03= float(input("Digite o Valor do primeiro Produto: "))
if (valor01 < valor02)and(valor01<valor03):
    print (produto1)
if (valor02 < valor01)and(valor02<valor03):
    print (produto2)
if (valor03 < valor02)and(valor03<valor02):
    print (produto3)


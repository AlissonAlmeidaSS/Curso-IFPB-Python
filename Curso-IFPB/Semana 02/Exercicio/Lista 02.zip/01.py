turno=input("Digite abreviado qual turno você estuda: ")
if (turno == "M"):
    print("Bom Dia")
if(turno == "N"):
    print("Boa Noite")
if (turno == "V"):
    print("Boa Tarde")
if(turno != "V")and(turno != "N")and (turno != "M"):
    print("Valor Invalido")

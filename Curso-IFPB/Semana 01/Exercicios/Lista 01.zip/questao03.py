num1 = int(input("Digite o Primeiro Numero: "))
num2 = int(input("Digite o Segundo Numero: "))
soma = num1+num2
print("A soma = ", soma)
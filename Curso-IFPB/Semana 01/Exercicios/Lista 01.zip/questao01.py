questoes = int(input("Digite a quantidade de Acertos na Prova: "))
percentual = questoes/50*100
print("Percentual =",percentual,"% de acertos")

acerto = int(input("Digite a quantidade de Acertos: "))
acerto = acerto*3
erros = int(input("Digite a quantidade de Erros: "))
branco = int(input("Digite a quantidade de Branco: "))
resultado = acerto-erros
print("O Resultado Final = ", resultado)
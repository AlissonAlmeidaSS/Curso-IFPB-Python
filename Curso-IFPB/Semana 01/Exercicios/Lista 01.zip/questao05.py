lado = int(input("Digite o Valor do Lado Quadrado: "))
area = lado*lado
print("Area do Quadrado =",area) 
dobro = area*2
print("O Dobro =", dobro)
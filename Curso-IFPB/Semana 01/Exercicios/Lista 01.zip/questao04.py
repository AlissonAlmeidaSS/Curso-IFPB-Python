nota01 = int(input("Digite a Primeira Nota: "))
nota02 = int(input("Digite a Segundo Nota: "))
nota03 = int(input("Digite a Terceira Nota: "))
media = (nota01+nota02+nota03)/3
print("A Media = ", media)